#!/usr/bin/ksh93

# do not execute this script directly!!!
# source it!!!

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-29 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

if [ "${isIbmUser}" = '1' ]; then
   echo "$script: Wait until list of servers is generated..." >&2
else
   echo "$script: Bitte warten bis Serverliste generiert wurde..." >&2
fi

serverfile="/tmp/$script.$(id -un).$$.server.txt"
nodefile="/tmp/$script.$(id -un).$$.node.txt"
nodelistfile="/tmp/$script.$(id -un).$$.nodelist.txt"
serverlistfile="/tmp/$script.$(id -un).$$.serverlist.txt"
clusterfile="/tmp/$script.$(id -un).$$.cluster.txt"
log4j_path=""
if [ -z "$envid" ] ; then
        echo "$script: no support for WAS6 anymore" >&2
        doexit 1
else
        for f in $(find /opt/was/$envid/profiles -name "serverindex.xml" | grep -v "/templates/" | grep "aps") ; do
                node="$f"
                node="${node##*nodes/}"
                node="${node%%/*}"
                grep "serverType=\"APPLICATION_SERVER\"" "$f" | sed -e 's/.*serverName="//' -e 's/".*//' | sort -u | while read server ; do
                        echo "$server" >> "$serverfile"
                        echo "$node" >> "$nodefile"
                done
        done
        #/opt/ebk/util/wsadmin -envid $envid $batch -c "import ebkutils; ebkutils.displayServerStatus()" > "$serverfile"
        rc=$?
fi

if [ $rc -ne 0 ] ; then
        sort -u "$serverfile"
        sort -u "$nodefile"
        rm -f "$serverfile" 2>/dev/null
        rm -f "$nodefile" 2>/dev/null
        doexit $rc
fi


###
# show radiolist
###
if [ "${isIbmUser}" = '1' ]; then
   servercmd="dialog --checklist \"Select cluster to restart\" 24 50 15"
else
   servercmd="dialog --checklist \"Cluster fuer Restart auswaehlen\" 24 50 15"
fi

n=0

res=-1
old_l=""
sort -u "$serverfile" | while read l ; do
        cluster="${l%_*}"
        if [ "$cluster" == "$old_l" ] ; then
                continue
        fi
        n=$((n+1))
        servercmd="$servercmd $n \"$cluster\" off"
        echo "$cluster" >> "$clusterfile"
        old_l="$cluster"
done

if [ -n "$arg" ] ; then
        res=$(grep -n "$arg" "$clusterfile" | cut -d ':' -f 1)
        if [ -z "$res" ] ; then
                res=-1
        fi
fi

if [ $res -lt 0 ] ; then
        servercmd="res=\$($servercmd 2>&1 > /dev/tty)"
        eval "$servercmd"

        res=$(echo "$res" | tr '"' ' ')
fi

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi


sort -u "$nodefile" | while read node ; do
        printf "\"$node\"," >> "$nodelistfile"
done


restart_cluster() {
        cluster="$1"
        echo "$script: restarting cluster $cluster ..."
        sort -u "$serverfile" | while read server ; do
                if [ "${cluster}_" == "${server%_*}_" ] ; then
                        printf "\"$server\"," >> "$serverlistfile"
                fi
        done
}


###
# get value for selection
###
cluster=""
n=0
sort -u "$clusterfile" | while read l ; do
        n=$((n+1))
        for x in $res ; do
                if [ $x -eq $n ] ; then
                        cluster="$l"
                        restart_cluster "$cluster"
                fi
        done
done


nodes=$(cat "$nodelistfile")
servers=$(cat "$serverlistfile")

echo "$script: restarting clusters ..."
rc=1
if [ -z "$envid" ] ; then
        /opt/ebk/util/wsadmin -stage $stage -cell $cellnr $batch \
                -c "restartAppServerAndMail([$servers],[$nodes],None,\"Restart by Operator $(id -unl)\")"
        rc=$?
else
        wasnode=""
        if [ $(ls -1 /opt/was/$envid/profiles | wc -l | awk '{print $1}') -gt 1 ] ; then
                wasnode="-wasnode $(ls -1 /opt/was/$envid/profiles | grep "dpl.*_1")"
        fi
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "import ebkutils; ebkutils.restartAppServerAndMail([$servers],[$nodes],None,\"Restart by Operator $(id -unl)\")"
        rc=$?
fi
if [ $rc -eq 0 ] ; then
        echo "$script: restarting clusters successful"
else
        echo "$script: restarting clusters failed"
fi




rm -f "$clusterfile" 2>/dev/null
rm -f "$serverfile" 2>/dev/null
rm -f "$nodefile" 2>/dev/null
rm -f "$nodelistfile" 2>/dev/null
rm -f "$serverlistfile" 2>/dev/null
doexit $rc
