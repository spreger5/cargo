#!/usr/bin/ksh93

# do not execute this script directly!!!
# source it!!!

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

if [ "${isIbmUser}" = '1' ]; then
   echo "$script: Wait until list of nodes is generated..." >&2
else
   echo "$script: Bitte warten bis Nodeliste generiert wurde..." >&2
fi

statusfile="/tmp/$script.$(id -un).$$.status.txt"

if [ -z "$envid" ] ; then
        echo "$script: This is not supported on the stage."
        rc=1
        doexit $rc
else
        ls -1 /opt/was/$envid/profiles/*/dmgr/config/cells/$envid/nodes/ > "$statusfile"
fi


###
# show radiolist
###
restartcmd="dialog --radiolist \"Node fuer Stop auswaehlen\" 20 50 15"

n=0

while read l ; do
        n=$((n+1))
        restartcmd="$restartcmd $n \"$l\" off"
done < "$statusfile"

res=-1
restartcmd="res=\$($restartcmd  2>&1 > /dev/tty)"
eval "$restartcmd"

res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi


###
# get value for selection
###
node=""
n=0
while read l ; do
        n=$((n+1))
        if [ $n -eq $res ] ; then
                node=$(echo "$l" | cut -d' ' -f1)
        fi
done < "$statusfile"

echo "$script: stopping node $node ..."

wasnode=""
if [ $(ls -1 /opt/was/$envid/profiles | wc -l | awk '{print $1}') -gt 1 ] ; then
        wasnode="-wasnode $(ls -1 /opt/was/$envid/profiles | grep "dpl.*_1")"
fi

/opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
        -c "import ebkutils; ebkutils.stop_node_mail_and_wait(\"$node\",600,None,\"Stop Node $node by Operator $(id -unl)\")"
rc=$?


rm -f "$statusfile" 2>/dev/null
doexit $rc
