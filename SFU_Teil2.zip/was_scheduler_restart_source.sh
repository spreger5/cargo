#!/bin/sh

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

PATH="$PATH:/opt/ebk/util"
CACHE_DIR="/var/log/monitoring/was_scheduler_restart"

if [ ! -d "$CACHE_DIR" ] ; then
        mkdir "$CACHE_DIR"
        chgrp waoper "$CACHE_DIR"
        chmod 2770 "$CACHE_DIR"
fi

if [ -z "$envid" ] ; then
        echo "$script: missing envid" >&2
        doexit 1
fi

cache_file="was_scheduler_restart_cache_$envid.txt"

cfgdir=$(ls -1d /opt/was/"$envid"/profiles/*ddpl*/dmgr/config/cells/"$envid" | head -1)
if [ -z "$cfgdir" ]
then
        cfgdir=$(ls -1d /opt/was/"$envid"/profiles/dmgr/config/cells/"$envid" | head -1)
fi
xmlfiles=$(find "$cfgdir" \
        -name "resources-pme.xml" -type f -newer "$CACHE_DIR/$cache_file" 2>/dev/null)

wasutil="/opt/ebk/util/was7"
if [ ! -d "$wasutil" ]
then
        wasutil="/opt/ebk/util/was85"
fi

if [ ! -f "$CACHE_DIR/$cache_file" ] || [ -n "$xmlfiles" ] || [ $(tail -1 "$CACHE_DIR/$cache_file") != "###EOF###" ] ; then
        wsadmin -batch -envid "$envid" -f "$wasutil/was_scheduler_list.py" "$CACHE_DIR/$cache_file"
        rc=$?
        if [ $rc -ne 0 ] ; then
                echo "$script: wsadmin call failed: $rc" >&2
                doexit $rc
        fi
fi


if [ "${isIbmUser}" = '1' ]; then
   sccmd="dialog --radiolist \"Select scheduler (cmd $remotescript)\" 24 60 15"
else
   sccmd="dialog --radiolist \"Scheduler auswaehlen (cmd $remotescript)\" 24 60 15"
fi

n=1
res=-1
while read line ; do
        if [ "$line" != "###EOF###" ] ; then
                sccmd="$sccmd $n \"${line}\" off"
                n=$((n+1))
        else
                break
        fi
done < "$CACHE_DIR/$cache_file"

sccmd="res=\$($sccmd 2>&1 > /dev/tty)"
eval "$sccmd"
res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi

n=1
sc=""
while read line ; do
        if [ "$n" == "$res" ] ; then
                sc="$line"
                break
        fi
        n=$((n+1))
done < "$CACHE_DIR/$cache_file"

wsadmin -batch -envid "$envid" -f "$wasutil/was_scheduler_restart.py" "$sc"
rc=$?
if [ $rc -ne 0 ] ; then
        echo "$script: wsadmin call failed: $rc" >&2
        doexit $rc
fi

doexit 0
