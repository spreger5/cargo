#!/usr/bin/ksh93

# do not execute this script directly!!!
# source it!!!

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

if [ "${isIbmUser}" = '1' ]; then
   echo "$script: Wait until list of servers is generated..." >&2
else
   echo "$script: Bitte warten bis Serverliste generiert wurde..." >&2
fi

serverfile="/tmp/$script.$(id -un).$$.server.txt"
if [ -z "$envid" ] ; then
        echo "$script: no support for WAS6 anymore" >&2
        doexit 1
else
        for f in $(find /opt/was/$envid/profiles -name "serverindex.xml" | grep -v "/templates/" | grep "aps") ; do
                node="$f"
                node="${node##*nodes/}"
                node="${node%%/*}"
                grep "serverType=\"APPLICATION_SERVER\"" "$f" | sed -e 's/.*serverName="//' -e 's/".*//' | sort -u | while read server ; do
                        echo "$server $node" >> "$serverfile"
                done
        done
        rc=$?
fi

if [ $rc -ne 0 ] ; then
        sort -u "$serverfile"
        rm -f "$serverfile" 2>/dev/null
        doexit $rc
fi


###
# show checklist
###
if [ "${isIbmUser}" = '1' ]; then
   servercmd="dialog --checklist \"Select server to collect data for analysis\" 24 50 15"
else
   servercmd="dialog --checklist \"Server zur Analysedatensammlung auswaehlen\" 24 50 15"
fi

n=0

old_l=""
sort -u "$serverfile" | while read l ; do
        n=$((n+1))
        servercmd="$servercmd $n \"$l\" off"
done

res=-1
servercmd="res=\$($servercmd 2>&1 > /dev/tty)"
eval "$servercmd"

res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi

wasnode=""
if [ $(ls -1 /opt/was/$envid/profiles | wc -l | awk '{print $1}') -gt 1 ] ; then
        wasnode="-wasnode $(ls -1 /opt/was/$envid/profiles | grep "dpl.*_1")"
fi

wait_for_job() {
        jobfile="$1"
        targethost="$2"

        echo "Waiting for finishing job $jobfile on host $targethost"
        sleeptime=2
        while [[ $(sleep $sleeptime; echo $?) -eq 0 ]]
        do
                inputqueue="/opt/ebk/jobexec/jobexec_wasys/${targethost}/input"
                workqueue="/opt/ebk/jobexec/jobexec_wasys/${targethost}/work"
                failedqueue="/opt/ebk/jobexec/jobexec_wasys/${targethost}/failed"
                succeededqueue="/opt/ebk/jobexec/jobexec_wasys/${targethost}/succeeded"
                sleeptime=2
                if [[ -e "$inputqueue/$jobfile" ]]
                then
                        sleeptime=2
                        continue
                elif [[ -n "$(ls -1 "$workqueue"/${jobfile}* 2>/dev/null)" ]]
                then
                        sleeptime=10
                        jobout="$(ls -1 "$workqueue"/${jobfile}*.stdout 2>/dev/null)"
                        if [[ -n "$jobout" ]] && [[ -n $(find "$jobout" -mmin +10) ]]
                        then
                                echo "Hanging job $jobfile on host $targethost"
                                if [[ $is_force -eq 1 ]]
                                then
                                        # option to continue on failing
                                        break
                                else
                                        exit 1
                                fi
                        elif [[ -n "$jobout" ]]
                        then
                                echo "Running active job $jobfile on host $targethost ..."
                                tail -3 "$jobout" | while read l
                                do
                                        echo "    $l"
                                done
                        fi
                        continue
                elif [[ -n "$(ls -1 "$succeededqueue"/${jobfile}*.rc 2>/dev/null)" ]]
                then
                        echo "Succeeded job $jobfile on host $targethost"
                        break
                elif [[ -n "$(ls -1 "$failedqueue"/${jobfile}*.rc 2>/dev/null)" ]]
                then
                        joberr="$(ls -1 "$failedqueue"/${jobfile}*.stderr 2>/dev/null)"
                        if [[ -n "$joberr" ]]
                        then
                                tail -15 "$joberr" | while read l
                                do
                                        echo "    $l"
                                done
                        fi
                        echo "Failed job $jobfile on host $targethost"
                        if [[ $is_force -eq 1 ]]
                        then
                                # option to continue on failing
                                break
                        else
                                exit 1
                        fi
                else
                        sleeptime=2
                        echo "Undefined state for job $jobfile on host $targethost"
                fi
        done
}


gen_analyzedata() {
        server="$1"
        node="$2"

        if [ "${isIbmUser}" = '1' ]; then
           echo "$script: generates analysis data for server $server on node $node ..."
           echo ""
           echo "\t\tfollowing data are collected:"
           echo "\t\t 3 JavaCores (one at start and two at end)"
           echo "\t\t 1 AIX-Core (gencore)"
           echo "\t\t 1 HeapDump"
           echo ""
        else
           echo "$script: generiert Analysedaten fuer den Server $server am Knoten $node ..."
           echo ""
           echo "\t\tdabei werden folgende Daten gesammelt:"
           echo "\t\t 3 JavaCores (zu Beginn einer und zum Schluss 2)"
           echo "\t\t 1 AIX-Core (gencore)"
           echo "\t\t 1 HeapDump"
           echo ""
        fi

        echo ""
        echo "Step 1 of 5: First JavaCore"
        echo ""

        jc1_rc=1
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "jvm=AdminControl.completeObjectName(\"type=JVM,node=$node,process=$server,*\"); AdminControl.invoke(jvm, \"dumpThreads\")"
        jc1_rc=$?
        if [ $jc1_rc -eq 0 ] ; then
                echo "$script: JavaCore 1 successful"
        else
                echo "$script: JavaCore 1 failed"
        fi

        echo ""
        echo "Step 2 of 5: AIX-Core"
        echo ""

        aixcore_rc=1
        #read the AIX-Name from the responsefile ..
        aixnodename=$(grep $node /opt/ebk/deployment/installation/responsefiles/${envid}/${envid}_cell_definitions.txt| awk '{split($0,a,","); print a[3]}' )
        if [[ $aixnodename == "" ]]; then
                aixcore_rc=12
        else

                #echo $aixnodename

                datevar=$( date +%Y%m%d%H%M%S )
                jobexec_file="job_was85_gencore_job_${datevar}"
                jobexec_dir="/opt/ebk/jobexec/jobexec_wasys/${aixnodename}/input/"

                echo "
pid=\$(ps -ef | grep -E \"$envid .* $server\" | grep -v grep | awk '{ print \$2 }' )
#echo \$pid
gencorefile=/opt/heapdump/gencore_${envid}_${node}_${server}_\${pid}_\$(date +\"%Y%m%d%H%M%S\").dmp
#echo \$pid
if [[ \$pid = +([[:digit:]]) ]] ; then
        /usr/bin/gencore \$pid \$gencorefile
        exit $?
else
        echo \"No valid PID found .. no AIX-Core generated\"
        exit 12
fi"  > ${jobexec_dir}/${jobexec_file}

                #echo ${jobexec_dir}/${jobexec_file}

                chmod u+x ${jobexec_dir}/${jobexec_file}

                date
                # wait for job completion
                wait_for_job $jobexec_file ${aixnodename}

                aixcore_rc=$?

                date

        fi

        if [ $aixcore_rc -eq 0 ] ; then
                echo "$script: AIX-Core $gencorefile successful"
        else
                echo "$script: AIX-Core failed"
        fi

        echo ""
        echo "Step 3 of 5: HeapDump"
        echo ""

        hd_rc=1
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "import ebkutils; ebkutils.generateHeapDump(\"$server\", \"$node\")"
        hd_rc=$?
        if [ $hd_rc -eq 0 ] ; then
                echo "$script: HeapDump successful"
        else
                echo "$script: HeapDump failed"
        fi

        echo ""
        echo "Step 4 of 5: second JavaCore"
        echo ""

        jc2_rc=1
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "jvm=AdminControl.completeObjectName(\"type=JVM,node=$node,process=$server,*\"); AdminControl.invoke(jvm, \"dumpThreads\")"
        jc2_rc=$?
        if [ $jc2_rc -eq 0 ] ; then
                echo "$script: JavaCore 2 successful"
        else
                echo "$script: JavaCore 2 failed"
        fi
        echo ""
        echo "sleep 100 seconds..."
        sleepTotal=100
        sleep=0
        sleeped=0
        while (( $sleeped < $sleepTotal )); do
                tosleep=$(( $sleepTotal-$sleeped ))
                sleep=$(( $tosleep/2 ))
                if [[ $sleep < 1 ]]; then sleep=1; fi
                sleeped=$(( $sleeped+$sleep ))
                echo "noch $tosleep"
                sleep $sleep
        done
        echo ""
        echo "Step 5 of 5: third JavaCore"
        echo ""
        jc3_rc=1
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "jvm=AdminControl.completeObjectName(\"type=JVM,node=$node,process=$server,*\"); AdminControl.invoke(jvm, \"dumpThreads\")"
        jc3_rc=$?
        if [ $jc1_rc -eq 0 ] ; then
                echo "$script: JavaCore 3 successful"
        else
                echo "$script: JavaCore 3 failed"
        fi

        echo ""

        if [ "${isIbmUser}" = '1' ]; then
           echo "Done"
        else
           echo "Erledigt"
        fi

        echo ""

        return $((hd_rc+jc1_rc+jc2_rc+jc3_rc+aixcore_rc))
}


###
# get value for selection
###
cluster=""
n=0
sum_rc=0
sort -u "$serverfile" | while read l ; do
        n=$((n+1))
        for x in $res ; do
                if [ $x -eq $n ] ; then
                        server=$(echo "$l" | cut -d' ' -f1)
                        node=$(echo "$l" | cut -d' ' -f2)
                        gen_analyzedata $server $node
                        rc=$?
                        sum_rc=$((sum_rc+rc))
                fi
        done
done

rm -f "$serverfile" 2>/dev/null
doexit $sum_rc

