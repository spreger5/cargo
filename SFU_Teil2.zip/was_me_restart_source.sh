#!/bin/sh

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

PATH="$PATH:/opt/ebk/util"
CACHE_DIR="/var/log/monitoring/was_me_restart"

if [ ! -d "$CACHE_DIR" ] ; then
        mkdir "$CACHE_DIR"
        chgrp waoper "$CACHE_DIR"
        chmod 2770 "$CACHE_DIR"
fi

if [ -z "$envid" ] ; then
        echo "$script: missing envid" >&2
        doexit 1
fi

cache_file="was_me_restart_cache_$envid.txt"

cfgdir=$(ls -1d /opt/was/"$envid"/profiles/*ddpl*/dmgr/config/cells/"$envid" | head -1)
if [ -z "$cfgdir" ]
then
        cfgdir=$(ls -1d /opt/was/"$envid"/profiles/dmgr/config/cells/"$envid" | head -1)
fi
xmlfiles=$(find "$cfgdir" \
        -name "sib-engines.xml" -type f -newer "$CACHE_DIR/$cache_file" 2>/dev/null)
if [ -z "$xmlfiles" ]
then
        cfgdir="$cfgdir/buses"
        xmlfiles=$(find "$cfgdir" \
                -name "sib-bus.xml" -type f -newer "$CACHE_DIR/$cache_file" 2>/dev/null)
fi

wasutil="/opt/ebk/util/was7"
if [ ! -d "$wasutil" ]
then
        wasutil="/opt/ebk/util/was85"
fi

if [ ! -f "$CACHE_DIR/$cache_file" ] || [ -n "$xmlfiles" ] || [ $(tail -1 "$CACHE_DIR/$cache_file") != "###EOF###" ] ; then
        wsadmin -batch -envid "$envid" -f "$wasutil/was_me_list.py" "$CACHE_DIR/$cache_file"
        rc=$?
        if [ $rc -ne 0 ] ; then
                echo "$script: wsadmin call failed: $rc" >&2
                doexit $rc
        fi
fi

if [ "${isIbmUser}" = '1' ]; then
   mecmd="dialog --radiolist \"Select MessageEngine (cmd $remotescript)\" 24 60 15"
else
   mecmd="dialog --radiolist \"MessageEngine auswaehlen (cmd $remotescript)\" 24 60 15"
fi

n=1
res=-1
while read line ; do
        if [ "$line" != "###EOF###" ] ; then
                mecmd="$mecmd $n \"${line}\" off"
                n=$((n+1))
        else
                break
        fi
done < "$CACHE_DIR/$cache_file"

mecmd="res=\$($mecmd 2>&1 > /dev/tty)"
eval "$mecmd"
res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi

n=1
me=""
while read line ; do
        if [ "$n" == "$res" ] ; then
                me="$line"
                break
        fi
        n=$((n+1))
done < "$CACHE_DIR/$cache_file"

wsadmin -batch -envid "$envid" -f "$wasutil/was_me_restart.py" "$me"
rc=$?
if [ $rc -ne 0 ] ; then
        echo "$script: wsadmin call failed: $rc" >&2
        doexit $rc
fi

doexit 0
