#!/usr/bin/ksh93

# do not execute this script directly!!!
# source it!!!

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

if [ "${isIbmUser}" = '1' ]; then
   echo "$script: Wait until list of servers is generated..." >&2
else
   echo "$script: Bitte warten bis Serverliste generiert wurde..." >&2
fi

statusfile="/tmp/$script.$(id -un).$$.status.txt"
log4j_path=""
if [ -z "$envid" ] ; then
        echo "$script: no support for WAS6 anymore" >&2
        doexit 1
else
        for f in $(find /opt/was/$envid/profiles -name "serverindex.xml" | grep -v "/templates/" | grep "aps") ; do
                node="$f"
                node="${node##*nodes/}"
                node="${node%%/*}"
                grep "serverType=\"APPLICATION_SERVER\"" "$f" | sed -e 's/.*serverName="//' -e 's/".*//' | sort -u | while read server ; do
                        echo "$server $node" >> "$statusfile"
                done
        done
        #/opt/ebk/util/wsadmin -envid $envid $batch -c "import ebkutils; ebkutils.displayServerStatus()" > "$statusfile"
        rc=$?
fi

if [ $rc -ne 0 ] ; then
        sort -u "$statusfile"
        rm -f "$statusfile" 2>/dev/null
        doexit $rc
fi

###
# ask for package
###
askpkg=1
while [ $askpkg -eq 1 ] ; do
pkgcmd="dialog --inputbox \"Enter java package\" 24 50 \"at.co.arz.?\""
res=-1
pkgcmd="res=\$($pkgcmd 2>&1 > /dev/tty)"
eval "$pkgcmd"
log4j_package="$res"

echo "$log4j_package" | grep "^[a-zA-Z0-9]*\.[a-zA-Z0-9]*\.[a-zA-Z0-9]*\.[a-zA-Z0-9]*[a-zA-Z0-9\.]*$" >/dev/null 2>&1
if [ $? -ne 0 ] ; then
        msgcmd="dialog --msgbox \"Package is not allowed.\" 7 30  2>&1 > /dev/tty"
        eval "$msgcmd"
else
        askpkg=0
fi
done

###
# ask for level
###
lvlcmd="dialog --radiolist \"Select Log4J level\" 24 50 15"
lvlcmd="$lvlcmd 1 \"DEBUG\" off 2 \"INFO\" off 3 \"ERROR\" off"
res=-1
lvlcmd="res=\$($lvlcmd 2>&1 > /dev/tty)"
eval "$lvlcmd"
log4j_level=""
if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
elif [ $res -eq 1 ] ; then
        log4j_level="DEBUG"
elif [ $res -eq 2 ] ; then
        log4j_level="INFO"
elif [ $res -eq 3 ] ; then
        log4j_level="ERROR"
fi

###
# show radiolist
###
servercmd="dialog --checklist \"Select server for Log4J configuration\" 24 50 15"

n=0

sort -u "$statusfile" | while read l ; do
        n=$((n+1))
        servercmd="$servercmd $n \"$l\" off"
done

res=-1
servercmd="res=\$($servercmd 2>&1 > /dev/tty)"
eval "$servercmd"

res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi


log4j_path=""
if [ -z "$envid" ] ; then
        log4j_path="/opt/ebk/was/$stage/c0$cellnr/m086/nodeagent/config/cells/*/nodes/*/servers/\$server/appconf/log4jconfig.xml"
else
        log4j_path="/opt/was/$envid/profiles/*/nodeagent/config/cells/$envid/nodes/*/servers/\$server/appconf/log4jconfig.xml"
fi

log4j_config() {
        host="${node%_*}"
        echo "$script: configure log4j for server $server at host $host ..."
        echo "$script: will lookup log4jconfig $log4j_path ..."
        log4j_file="empty"
        eval "log4j_file=\"$log4j_path\""
        echo "$script: will lookup log4jconfig $log4j_file ..."
        ssh -t -A "$host" "/opt/ebk/util/was_log4j_modify.sh -f \"$log4j_file\" -p \"$log4j_package\" -l \"$log4j_level\""
}

###
# get value for selection
###
server=""
node=""
n=0
sort -u "$statusfile" | while read l ; do
        n=$((n+1))
        for x in $res ; do
                if [ $x -eq $n ] ; then
                        server=$(echo "$l" | cut -d' ' -f1)
                        node=$(echo "$l" | cut -d' ' -f2)
                        log4j_config
                fi
        done
done


rm -f "$statusfile" 2>/dev/null
doexit $rc
