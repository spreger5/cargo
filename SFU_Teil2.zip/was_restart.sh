#!/usr/bin/ksh93

PATH="/bin:/sbin:/usr/bin:/usr/sbin"

#----------------------------------------------------------------------------------------------
# Dieses Script baut eine grafische Auswahlliste auf, in der man die gewuenschte ENVID
# auswaehlen kann. Dannach wird das jeweilige *_source.sh Script mit der ENVID als Parameter aufgerufen.
# z.B. man ruft was_clusterrestart auf, mittels Symlink gelangt man auf dieses Script, dort waehlt man
# eine ENVID aus und dannach wird das Script was_clusterrestart_source.sh mit der gewaehlten ENVID
# als Parameter aufgerufen. Dieses fuehrt dann die eigentliche Restart Prozedur aus.
#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-29 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#--------------------------------------------------------------------------------------------------------------
# Im Array 'ENVIDS' werden in doppelten Anfuehrungsstrichen alle gueltigen envids und der dazugehoerige
# dmgr mit einem LEERZEICHEN getrennt eingetragen, pro Zeile eine envid. WICHTIG, am Ende der Zeile EIN Leerzeichen
# gefolgt von einem Backslash um die Newline zu escapen.

ENVIDS=(\
"iebk851 iadpl41a1" \
"iebk852 iadpl41a1" \
"iecm851 iadpl41c1" \
"ipoc852 iadpl41a1" \
"tebk851 tadpl41a1" \
"tebk852 tadpl41a1" \
"tebk854 tadpl42a1" \
"tebk856 tadpl41a1" \
"tado851 tadpl41d1" \
"tecm851 tadpl41c1" \
"tidc851 tadpl41e1" \
"vebk851 vadpl31a1" \
"vebk854 vadpl32a1" \
"vecm851 vadpl31c1" \
"vidc851 vadpl31e1" \
"vado851 vadpl31d1" \
"bebk851 badpl31a1" \
"xebk851 xadpl31a1" \
"xebk853 xadpl31b1" \
"xecm851 xadpl31c1" \
"nebk851 nadpl31a1" \
"necm851 nadpl31c1" \
"pebk851 padpl31a1" \
"pebk853 padpl31b1" \
"pebk854 padpl32a1" \
"pado851 padpl31d1" \
"pecm851 padpl31c1" \
"pidc851 padpl31e1" \
)

script="$(basename $0)"

if [ "$(id -un)" != "$(id -unl)" ] ; then
        echo "$script: You need to be user $(id -unl)!" >&2
        exit 1
fi

callscript="was_restart_sudo.sh"
remotescript="none"
if [ "${script#was_restart}" != "$script" ] ; then              # Festlegen welches Script am Ende aufgerufen werden soll.
        remotescript="was_restart_source.sh"
elif [ "${script#was_node_stop}" != "$script" ] ; then
        remotescript="was_node_stop_source.sh"
elif [ "${script#was_stop}" != "$script" ] ; then
        remotescript="was_stop_source.sh"
elif [ "${script#was_clusterrestart}" != "$script" ] ; then
        remotescript="was_clusterrestart_source.sh"
elif [ "${script#was_gen_analyzedata}" != "$script" ] ; then
        remotescript="was_gen_analyzedata_source.sh"
elif [ "${script#was_me_restart}" != "$script" ] ; then
        remotescript="was_me_restart_source.sh"
elif [ "${script#was_scheduler_restart}" != "$script" ] ; then
        remotescript="was_scheduler_restart_source.sh"
elif [ "${script#was_log4j}" != "$script" ] ; then
        callscript="was_restart_nosudo.sh"
        remotescript="was_log4j_source.sh"
else
        echo "$script: This script is not installed with correct filename!" >&2
        exit 1
fi

# Aufbauen des 'dialog' Befehls, der die Radiolist erzeugt.

if [ "${isIbmUser}" = '1' ]; then
   envidlist="dialog --stdout --radiolist \"$script: Select an envid!\" 24 60 15"
else
   envidlist="dialog --stdout --radiolist \"$script: Bitte eine envid auswaehlen!\" 24 60 15"
fi

result=-1
for i in "${!ENVIDS[@]}"; do                                   # Fuer jeden ENVIDS Eintrag das erste Wort nehmen
        envid=$(echo ${ENVIDS[$i]} | awk '{ print $1 }')       # und zur Radiolist hinzufuegen.
        envidlist="$envidlist $i $envid off"
        if [ "$envid" == "$1" ]; then                          # Pruefen ob dem Script eine korrekte envid
                result=$i                                      # aus der Liste mitgegeben wurde.
        fi
done

if [ $result -lt 0 ]; then
        eval "result=\$($envidlist)"                           # 'dialog' Befehl ausfuehren und Ergebnis in $result schreiben

        result=$(echo "$result" | tr '"' ' ')
fi

if [ -z "$result" ]; then
        echo "$script: aborted." >&2
        exit 0
fi

# Ergebnis des 'dialog' Befehls auswerten.
dmgr=$(echo ${ENVIDS[$result]} | awk '{ print $2 }')
envid=$(echo ${ENVIDS[$result]} | awk '{ print $1 }')

arg=""
if [ -n "$2" ] ; then
        arg="-a \"$2\""
fi

# Remotescript aufrufen...
echo "$script: connect $dmgr for envid $envid ..."
ssh -t -A "$dmgr" "/usr/bin/ksh93 -c \"/opt/ebk/util/$callscript -t $remotescript -b -e $envid $arg\""

rc=$?

exit $rc
