#!/usr/bin/ksh93

# do not execute this script directly!!!
# source it!!!

#----------------------------------------------------------------------------------------------
# Aenderungen: 2021-04-30 SprG
#                 - Die Ausgaben erfolgen fuer die IBM/-CIC-User in Englisch
#                   (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

userAkt=$(id|cut -f2 -d"("|cut -f1 -d")")

isIbmUser='0'

# User-IDs von externen MAs, wie den IBM-Usern, sind 8 (statt 7) Stellen lang, z.B.
# rpci9419 rpci9422 rpci9423 rpci9425 rpci9426

if [[ "${#userAkt}" -eq 8  &&  "${userAkt:0:5}" = "rpci9" ]]; then
   isIbmUser='1'
fi

#---

if [ "${isIbmUser}" = '1' ]; then
   echo "$script: Wait until list of servers is generated..." >&2
else
   echo "$script: Bitte warten bis Serverliste generiert wurde..." >&2
fi

statusfile="/tmp/$script.$(id -un).$$.status.txt"
if [ -z "$envid" ] ; then
        /opt/ebk/util/wsadmin -stage $stage -cell $cellnr $batch -c "displayServerStatus()" > "$statusfile"
        rc=$?
else
        wasnode=""
        if [ $(ls -1 /opt/was/$envid/profiles | wc -l | awk '{print $1}') -gt 1 ] ; then
                wasnode="-wasnode $(ls -1 /opt/was/$envid/profiles | grep "dpl.*_1")"
        fi
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch -c "import ebkutils; ebkutils.displayServerStatus()" > "$statusfile"
        rc=$?
fi

if [ $rc -ne 0 ] ; then
        cat "$statusfile"
        rm -f "$statusfile" 2>/dev/null
        doexit $rc
fi


###
# show radiolist
###

if [ "${isIbmUser}" = '1' ]; then
   restartcmd="dialog --radiolist \"Select server to stop\" 20 50 15"
else
   restartcmd="dialog --radiolist \"Server fuer Stop auswaehlen\" 20 50 15"
fi

n=0

grep "^\| [a-z_0-9]* .*\| [a-z0-9_]* .*\| [A-Z]* .*\| [0-9\-]*[ ]*$" "$statusfile" | \
        grep -v "| nodeagent" | grep -v "| webserver" | grep -v "| dmgr" | \
        awk '{print $2 " " $4}' | sort | while read l ; do
                n=$((n+1))
                restartcmd="$restartcmd $n \"$l\" off"
        done

res=-1
restartcmd="res=\$($restartcmd 2>&1 > /dev/tty)"
eval "$restartcmd"

res=$(echo "$res" | tr '"' ' ')

if [ -z "$res" ] ; then
        echo "$script: aborted." >&2
        doexit 0
fi


###
# get value for selection
###
server=""
node=""
n=0
grep "^\| [a-z_0-9]* .*\| [a-z0-9_]* .*\| [A-Z]* .*\| [0-9\-]*[ ]*$" "$statusfile" | \
        grep -v "| nodeagent" | grep -v "| webserver" | grep -v "| dmgr" | \
        awk '{print $2 " " $4}' | sort | while read l ; do
                n=$((n+1))
                if [ $n -eq $res ] ; then
                        server=$(echo "$l" | cut -d' ' -f1)
                        node=$(echo "$l" | cut -d' ' -f2)
                fi
        done

echo "$script: stopping server $server at node $node ..."

if [ -z "$envid" ] ; then
        /opt/ebk/util/wsadmin -stage $stage -cell $cellnr $batch \
                -c "AdminControl.stopServer(\"$server\",\"$node\")"
        rc=$?
else
        wasnode=""
        if [ $(ls -1 /opt/was/$envid/profiles | wc -l | awk '{print $1}') -gt 1 ] ; then
                wasnode="-wasnode $(ls -1 /opt/was/$envid/profiles | grep "dpl.*_1")"
        fi
        /opt/ebk/util/wsadmin -envid $envid $wasnode $batch \
                -c "import ebkutils; ebkutils.stop_server_on_node_and_mail(\"$server\",\"$node\",None,\"Stop by Operator $(id -unl)\")"
        rc=$?
fi


rm -f "$statusfile" 2>/dev/null
doexit $rc
