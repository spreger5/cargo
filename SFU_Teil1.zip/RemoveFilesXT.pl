#!/usr/bin/perl
#==============================================================================================
#  Files loeschen. Dies ist eine erweiterte Variante des Programms 'RemoveFiles.pl'.
#
#  Je Loeschvorgang werden 4 Groeszen vorgegeben:
#  ----------------------------------------------
#     - RmvStartDir          Verzeichnis, ab dem geloescht wird (keine Wildcards erlaubt)
#     - RmvFileSpecRE        zu loeschende Files als RegEx
#     - RmvFileAgeSeconds    Mindestalter letzte Aenderung in Sekunden, damit ein File geloescht wird
#     - RmvRemoveEmptyDirJN  Soll ein leeres Verzeichnis ab dem Start-VZ entfernt werden (Ja/Nein),
#                            seine letzte Aktualisierung muss mindestens 'RmvFileAgeSeconds' Sekunden
#                            zurueck liegen.
#
#  Ab dem Startverzeichnis 'RmvStartDir' wird in allen Unterverzeichnissen nach Dateien der
#  Spezifikation 'RmvFileSpecRE' gesucht.  Liegen deren letzte Modifikationen mindestens
#  'RmvFileAgeSeconds' Sekunden zurueck, werden sie geloescht.
#  Falls 'RmvRemoveEmptyDirJN' wahr ist, werden leere Verzeichnisse ab dem Startverzeichnis
#  'RmvStartDir' geloescht. Auch hier muss gelten, dass die letzte Modifikation eines
#  Verzeichnisses mindestens 'RmvFileAgeSeconds' Sekunden zurueck liegen muss, damit es geloescht wird.
#
#  Hinweis: Durch das Loeschen von Dateien in einem Verzeichnis wird dessen Modifikationszeit
#           mit dem Loeschzeitpunkt aktualisiert, da am Verzeichnis eine Aenderung vorgenommen wird.
#           Da dieses Programm zuerst Dateien und dann leere Verzeichnisse loescht, werden leere
#           Verzeichnisse normalerweise erst in einem spaeteren Programmaufruf geloescht.
#
#  Alle relevanten Werte werden ueber eine Konfigurationsdatei eingestellt.
#
#  Um die Plausibilitaet eines Timestamps zu erleichtern, wurde ein Algorithmus gewaehlt,
#  der Dateien prinzipiell nur dann loescht, wenn sie mindestens aus dem Jahr 2007 sind
#  und zum Laufzeitpunkt nicht in die Zukunft datieren.
#
#  T-Lib: /opt/monitoring/RemoveFilesXT
#
#----------------------------------------------------------------------------------------------
#  Parameter: -cfg <DSN>      [muss] ... DSN der Konfiguratiosdatei
#             -debug|nodebug  [kann] ... Debug-Infos werden (nicht) zusaetzlich ausgegeben
#----------------------------------------------------------------------------------------------
#  Erstellt von: Gerhard Sprenger
#            am: 05.09.2007
#----------------------------------------------------------------------------------------------
#  Aenderungen: 01. 07.05.2008  Sprenger
#                   - Gesamtsumme geloeschte Dirs/Files/Byte ausgeben
#                   - Zeitpunkt des Jobendes ausgeben
#                   - Zahlen aufbereiten (Tausenderpunkte)
#
#               02. 26.08.2008  Sprenger
#                   - Leere Verzeichnisse werden nur geloescht, wenn deren letzte Modifikation
#                     mindestens 'RmvFileAgeSeconds' Sekunden zurueck liegt.
#
#               03. 27.04.2021  Sprenger
#                   - Die Ausgaben erfolgen in Englisch, da dies die Kommunikationssprache mit
#                     den IBM/-CIC-Usern ist (CIC = Client Innovation Centre, IBM HU).
#----------------------------------------------------------------------------------------------

use strict; use warnings;
use Getopt::Long;
use File::Find;

if ($^O eq "MSWin32") { require Win32::Console::ANSI; }

# --- ANSI-Farben ----
my $ansiEsc = "\e["; # 0x1B [

my $ansiF_HRoSw = $ansiEsc . "1;31;40m";   # Hellrot auf Schwarz
my $ansiF_HGeSw = $ansiEsc . "1;33;40m";   # Hellgelb auf Schwarz
my $ansiF_HGrSw = $ansiEsc . "1;32;40m";   # Hellgruen auf Schwarz
my $ansiF_HWeSw = $ansiEsc . "1;37;40m";   # Hellweisz auf Schwarz
my $ansiF_NWeSw = $ansiEsc . "0;37;40m";   # Normalweisz auf Schwarz

# ---- Globale Einstellungen -------------------------------------------------------
my %sGblOptions = (  # globale Einstellungen. Anpassung ueber Befehlszeile moeglich
   'cfg'     => '?', # DSN der Konfigurationsdatei
   'debug'   =>  0 ,
                  );
my $bDebug;
my $bPrototyping = ($^O eq "MSWin32") ? 1 : 0;

my $sHostname = qx(hostname); chomp $sHostname;

my $fCfgDsn;                    # Name der Konfigurationsdatei

   # --- Die folgende globalen Werte werden in der Konfigurationsdatei gesetzt

my $gblLogfileDsn;              # DSN des Basis-Logfiles
my $gblLogfileCount;            # Max. Anzahl von Logfile-Backups
my $gblLogfileSize;             # Max. Groesze der Logdatei in Byte. Ist das Logfile zu Programmbeginn groeszer

my @RmvStartDir;                # Verzeichnis, ab dem geloescht wird (keine Wildcards erlaubt)
my @RmvFileSpecRE;              # zu loeschende Files als RegEx
my @RmvFileAgeSeconds;          # Mindestalter letzte Aenderung in Sekunden, damit ein File geloescht wird
my @RmvRemoveEmptyDirJN;        # Soll ein leeres Verzeichnis entfernt werden Ja/Nein

   # --- Die folgenden Groeszen werden fuer jeden Aufruf der Fallback-Routinen von 'File::Find' gesetzt

my $AktStartDir;                # Aktueller Wert des Start-VZ fuer 'File::Find' je Aufruf!!!
my $AktFileSpecRE;              # Aktueller Wert von '@RmvFileSpecRE', d.h. zu loeschende Files als RegEx

   # --- Die folgenden Groeszen werden in den Fallback-Routinen von 'File::Find' gesetzt

my @AktRmvFiles;                # zu loeschende Files
my @AktRmvDirs;                 # zu loeschende Dirs, aber nur falls sie leer sind
my @AktRmvFilesAndDirs;         # Alle Fileobjekte in einem Verzeichnis
my $AktRmvFilesAndDirsAnz;      # Anzahl aller Fileobjekte in einem Verzeichnis

   # ----------------------------------------------------------------------------

my $isNewLogfileRequired;       # Boolscher Wert, ob ein neues Logfile angelegt wurde

my $scrnColor;                  # Farbe fuer Win32-Meldung

my $sumAnzDirs  = 0;            # In Summe die Anzahl an geloeschten Verzeichnissen je Start-Verzeichnis
my $sumAnzFiles = 0;            # In Summe die Anzahl an geloeschten Files je Start-Verzeichnis
my $sumAnzBytes = 0;            # In Summe die Anzahl an geloeschten Bytes je Start-Verzeichnis

my $sumAnzDirsTotal  = 0;       # In Summe die Anzahl an geloeschten Verzeichnissen insgesamt
my $sumAnzFilesTotal = 0;       # In Summe die Anzahl an geloeschten Files insgesamt
my $sumAnzBytesTotal = 0;       # In Summe die Anzahl an geloeschten Bytes insgesamt

my $xFSize;                     # Groesze der akt. Datei
my $tMtime;                     # Zeitpunkt der letzen Modifikation in Epochensekunden

   # --- Groeszen fuer Datum und Zeit -------------------------------------------
my $tJetzt;                     # Aktuelle Zeit in Epochensekunden

my ($tJetztTag,   $tJetztMon,   $tJetztJhrJJJJ);
my ($tJetztSek,   $tJetztMin,   $tJetztStd);

   #--- Hilfsvariablen ---

my ($erg, $i, $j, $farbe, $x1, $x2, $x3, $sShellCmd, $xxx);

   #--- Fallback-Routinen zu 'File::Find' ---

   #
   # Erklaerung einiger Variablen, die 'File::Find' zur Verfuegung stellt:
   # ---------------------------------------------------------------------
   #
   #                $File::Find::name  $File::Find::dir  $_
   #   default      /                  /                 .
   #   no_chdir=>0  /etc               /                 etc
   #                /etc/x             /etc              x
   #
   #   no_chdir=>1  /                  /                 /
   #                /etc               /                 /etc
   #                /etc/x             /etc              /etc/x


sub GetAllFiles {

   # Dateien fuer vorgegebenes Muster ab Startverzeichnis ermitteln.
   # Links werden ignoriert.
   #
   # Globale Groeszen:  $AktFileSpecRE ... Aktueller Wert von '@RmvFileSpecRE',
   #                                       d.h. zu loeschende Files als RegEx
   #                    @AktRmvFiles   ... Ergebnis dieser Fallback-Routine

   my $sFqn;
   my $sFn;
   my $sDir;

   $sFqn = $File::Find::name;                 # voll qualifizierter DSN
   $sDir = $File::Find::dir;                  # voll qualifiziertes Verzeichnis

   return if -d $sFqn;                        # Verzeichnisse nicht verarbeiten
   return if -l $sFqn;                        # Links nicht verarbeiten

   $sFn  = substr($sFqn, length($sDir)+1);    # reiner Dateiname (ohne Verzeichnis)

   # Hinweis: '$File::Find::name' liefert keine Eintraege '.' und '..'
   #

   push @AktRmvFiles, $sFqn if $sFn =~ m/$AktFileSpecRE/;

}

sub GetAllDirs {

   # Verzeichnisse ab Startverzeichnis ermitteln. Das Startverzeichnis nicht zurueckgeben.
   # Links werden ignoriert.
   #
   # Globale Groeszen: $AktStartDir ... Start-VZ fuer den aktuellen Aufruf von 'File::Find'
   #                   @AktRmvDirs  ... Ergebnis dieser Fallback-Routine

   my $sFqn;

   $sFqn = $File::Find::name;                 # voll qualifizierter DSN

   return if -l $sFqn;                        # Links nicht verarbeiten
   return if $AktStartDir eq $sFqn;           # das Startverzeichnis NICHT zurueckgeben

   # Hinweis: '$File::Find::name' liefert keine Eintraege '.' und '..'
   #

   push @AktRmvDirs, $sFqn if -d $sFqn;       # nur Verzeichnisse verarbeiten

}

sub GetAllFilesAndDirs {

   # Alle Fileobjekte ab Startverzeichnis ermitteln. Links werden aber ignoriert.
   #
   # Globale Groeszen: $AktStartDir        ... Start-VZ fuer den aktuellen Aufruf von 'File::Find'
   #                   @AktRmvFilesAndDirs ... Ergebnis dieser Fallback-Routine

   my $sFqn;

   $sFqn = $File::Find::name;                 # voll qualifizierter DSN

   return if -l $sFqn;                        # Links nicht verarbeiten
   return if $AktStartDir eq $sFqn;           # das Startverzeichnis NICHT zurueckgeben

   # Hinweis: '$File::Find::name' liefert keine Eintraege '.' und '..'
   #

   push @AktRmvFilesAndDirs, $sFqn;           # alle File-Objkete verarbeiten

}

#-----------------------------------------------------------------------------------
#---   Operationaler Verarbeitungsteil   -------------------------------------------
#-----------------------------------------------------------------------------------

 GetOptions(
            'c|cfg:s'        => \$sGblOptions{'cfg'},
            'debug|verbose'  => \$sGblOptions{'debug'},
           );

 $bDebug  = $sGblOptions{'debug'};
 $fCfgDsn = $sGblOptions{'cfg'};

 if ($bDebug) {
    printf "\n%s\n", "Optionen:";
    foreach $x1 (keys %sGblOptions) {
       printf "   %s ist: >%s<\n", $x1, $sGblOptions{$x1};
    }
    print "\n";
 }


 #--- Befehlszeilen-Optionen pruefen ------------------------------------------------
 if (defined($fCfgDsn)  &&  $fCfgDsn ne '?'  &&  $fCfgDsn ne '' ) {
    unless (open(CFGFILE, "<", $fCfgDsn)) {
    #  print "Achtung: Kann Konfigurationsdatei '$fCfgDsn' nicht zum Lesen oeffnen!\n";
    #  print "         System meldet: $!\n";
    #  print "         Programm wird abgebrochen!!!\n";

       print "Attention: Configuration '$fCfgDsn' cannot be read!\n";
       print "           System reports: $!\n";
       print "           Program aborted!!!\n";
       exit 12;
    }
    close(CFGFILE);
 }
 else {
 #  print "Achtung: Kein Konfigurationsfile spezifiziert!\n";
 #  print "         Parameter -cfg verwenden!\n";
 #  print "         Programm wird abgebrochen!!!\n";

    print "Attention: No configuration file specified!\n";
    print "           Use Option -cfg ... !\n";
    print "           Program aborted!!!\n";
    exit 12;
 }

 $tJetzt = time;               # aktuelle Zeit in Epochensekunden

 ($tJetztSek, $tJetztMin, $tJetztStd, $tJetztTag, $tJetztMon, $tJetztJhrJJJJ) = (localtime($tJetzt))[0..5];
 $tJetztMon     += 1;
 $tJetztJhrJJJJ += 1900;


 GetVars($fCfgDsn);            # Globale Groeszen ex Konfigurationsdatei setzen

 if ($bPrototyping  || $bDebug) {
    print "DSN Logfile..................: >$gblLogfileDsn<.\n";
    print "Max. Anzahl Logfile-Backups..: >$gblLogfileCount<.\n";
    print "Max. Groesse Logfile in Byte.: >$gblLogfileSize<.\n";
    print "\n";

    foreach my $i (0 .. $#RmvStartDir) {
       print "Startverzeichnis (ohne Wildcards): >$RmvStartDir[$i]<.\n";
       print "Zu loeschende Dateien (RegEx)....: >$RmvFileSpecRE[$i]<.\n";
       print "Mindest-Alter in Sekunden........: >$RmvFileAgeSeconds[$i]<.\n";
       print "Leere Verzeichnisse entfernen....: >$RmvRemoveEmptyDirJN[$i]<.\n\n";
    }
 }


 #--- Logfile oeffnen. Groesze und Anzahl ist begrenzt. --------------------------------------------------------
 $isNewLogfileRequired = NewLogfileRequired();      # Logfile ggf. sichern und zuruecksetzen

#open LOG, ">>", $gblLogfileDsn or die "Kann Logfile '$gblLogfileDsn' nicht ueberschreiben. System meldet: $!.\n";
 open LOG, ">>", $gblLogfileDsn or die "Logfile '$gblLogfileDsn' cannot be modified. System reports: $!.\n";
 chmod 0664, $gblLogfileDsn;                        # rw-rw-r--

 $xxx = "-" x 100 . "\n"; Print2Log($xxx);
#$xxx = "Loesche Files auf Maschine '" . $sHostname . "' per " . GetActDateTime('Dt') . ".\n\n"; Print2Log($xxx);
 $xxx = "File deletion on node '" . $sHostname . "' at " . GetActDateTime('Dt') . ".\n\n"; Print2Log($xxx);


 #--- Files lt. Spezifikation loeschen und ggf. auch leere Verzeichnisse entfernen -----------------------------
 foreach my $i (0 .. $#RmvStartDir) {

    $AktStartDir   = $RmvStartDir[$i];
    $AktFileSpecRE = $RmvFileSpecRE[$i];

  # $xxx = "Startverzeichnis (ohne Wildcards): $AktStartDir\n";                               Print2Log($xxx);
  # $xxx = "Zu loeschende Dateien (RegEx)....: '$AktFileSpecRE'\n";                           Print2Log($xxx);
  # $xxx = "Mindest-Alter in Sekunden........: " . InterPunkt($RmvFileAgeSeconds[$i]) . "\n"; Print2Log($xxx);
  # $xxx = "Leere Verzeichnisse entfernen....: " . ($RmvRemoveEmptyDirJN[$i] ? 'Ja' : 'Nein') . "\n"; Print2Log($xxx);

    $xxx = "Starting directory (no wildcards)..: $AktStartDir\n";                               Print2Log($xxx);
    $xxx = "Files to be deleted (regular expr.): '$AktFileSpecRE'\n";                           Print2Log($xxx);
    $xxx = "Minimum age in seconds.............: " . InterPunkt($RmvFileAgeSeconds[$i]) . "\n"; Print2Log($xxx);
    $xxx = "Delete empty directories ..........: " . ($RmvRemoveEmptyDirJN[$i] ? 'Yes' : 'No') . "\n"; Print2Log($xxx);

    if ($^O ne 'MSWin32'  &&  substr($AktStartDir, 0, 1) ne '/') {
       $xxx = "Startverzeichnis beginnt nicht mit '/' und wird deshalb ignoriert!\n\n"; Print2Log($xxx);
       next;
    }


    if (!-e $AktStartDir) {
    #  $xxx = "Startverzeichnis existiert nicht und wird deshalb ignoriert!\n\n"; Print2Log($xxx);
       $xxx = "Starting directory does not exist and will be ignored!\n\n"; Print2Log($xxx);
       next;
    }


    #-------------------------------------------------------------------------------------------------------
    #--- Schritt 1: Ab dem Startverzeichnis 'RmvStartDir' in allen Unterverzeichnissen nach Dateien der
    #---            RegEx-Spezifikation 'RmvFileSpecRE' suchen.  Liegen deren letzte Modifikationen
    #---            mindestens 'RmvFileAgeSeconds' Sekunden zurueck, werden sie geloescht.
    #---

    ($sumAnzFiles, $sumAnzBytes) = (0, 0);

    @AktRmvFiles = ();

    find \&GetAllFiles, $AktStartDir;  # Array '@AktRmvFiles' einrichten. Alle Files ab Start-VZ lt. Spez.

    if ($bDebug) {
    #  print "Folgende Dateien lt. RegEx '$AktFileSpecRE' ab Startverzeichnis '$AktStartDir' gefunden:\n";
       print "Following files according to regular expression '$AktFileSpecRE' found in starting directory '$AktStartDir' and below:\n";
       print "  '$_'\n" foreach @AktRmvFiles;
    }

    foreach my $fn (@AktRmvFiles) {

       if (!-d $fn  &&  !-l $fn) {
          ($tMtime) = (stat($fn)) [9];               # Zeitpunkt der letzten Modifikation in Epochensekunden

          #--- "kurzlebige" Dateien sind zwar ermittelt worden, bis 'stat' ausgefuehrt wird
          #    existieren sie aber z.T. nicht mehr. Deshalb muss '$tMtime' noch auf Plausibilitaet
          #    geprueft werden.
          #
          #    2007-01-01 00:00:00  =  1167606000

          if (defined($tMtime)  &&  $tMtime>1167606000  &&  $tMtime<$tJetzt) {   # M-Time ist plausibel

             if ($tJetzt-$tMtime > $RmvFileAgeSeconds[$i]) {   # akt. Datei ist lt. Alter ein Loeschkandidat

                print "Loesche Datei '$fn'\n" if $bPrototyping;
                $xFSize = -s $fn;
                if (unlink($fn) == 1) {              # unlink retourniert die Anzahl erfolgreich geloeschter Dateien
                   $sumAnzFiles++;
                   $sumAnzBytes += $xFSize;
                }
             }
          }
       }
    }

    $sumAnzFilesTotal += $sumAnzFiles;          # Gesamtsumme aktualisieren
    $sumAnzBytesTotal += $sumAnzBytes;

  # $xxx = "Anzahl geloeschter Bestaende.....: " . InterPunkt($sumAnzFiles) . "\n"; Print2Log($xxx);
  # $xxx = "Anzahl geloeschter Byte..........: " . InterPunkt($sumAnzBytes) . "\n"; Print2Log($xxx);

    $xxx = "Number of deleted files............: " . InterPunkt($sumAnzFiles) . "\n"; Print2Log($xxx);
    $xxx = "Number of deleted bytes............: " . InterPunkt($sumAnzBytes) . "\n"; Print2Log($xxx);


    #-------------------------------------------------------------------------------------------------------
    #--- Schritt 2: Ab dem Startverzeichnis 'RmvStartDir' leere Unterverzeichnisse loeschen,
    #---            falls dies gewuenscht wird und falls deren letzte Modifikation mindestens
    #---            'RmvFileAgeSeconds[]' Sekunden zurueck liegt.

    #---
    #---            Damit mehrstufige Verzeichnisse sauber geloescht werden koennen,
    #---            muessen sie leer sein. Deshalb werden die Verzeichnisse nach deren
    #---            Namenslaenge absteigend sortiert, d.h der laengste Name kommt zuerst.
    #---

    if ($RmvRemoveEmptyDirJN[$i]) {

       $sumAnzDirs = 0;
       @AktRmvDirs = ();

       find \&GetAllDirs, $AktStartDir;  # Array '@AktRmvDirs' einrichten. Verzeichnisse ab Start-VZ
       @AktRmvDirs = sort {length($b) <=> length($a)} @AktRmvDirs; # laengste Name zuerst

       if ($bDebug) {
          print "Folgende Verzeichnisse ab Startverzeichnis '$AktStartDir' gefunden:\n";
          print "   '$_'\n" foreach @AktRmvDirs;
       }

       foreach my $dir (@AktRmvDirs) {

          $AktStartDir = $dir;
          @AktRmvFilesAndDirs = ();
          find \&GetAllFilesAndDirs, $AktStartDir;      # Array '@AktRmvFilesAndDirs' einrichten. Alle File-Objekte in '$dir'
          $AktRmvFilesAndDirsAnz = @AktRmvFilesAndDirs; # Anzahl File-Objekte in '$dir'

          if ($bDebug) {
             print "   '$AktStartDir' enthaelt $AktRmvFilesAndDirsAnz Fileobjekte.\n";
             if ($AktRmvFilesAndDirsAnz > 0) {
                print "   Es sind dies:\n";
                print "      '$_'\n" foreach @AktRmvFilesAndDirs;
             }
          }

          # Wenn ein Verzeichnis leer ist, darf es geloescht werden, wenn seine Modifikationszeit mindestens
          # 'RmvFileAgeSeconds[]' Sekunden zurueck liegt.
          if ($AktRmvFilesAndDirsAnz == 0  &&  -d $AktStartDir  &&  !-l $AktStartDir) {

             print "Verzeichnis ist leer: '$AktStartDir'\n" if $bDebug;

             ($tMtime) = (stat($AktStartDir)) [9];  # Zeitpunkt der letzten Modifikation in Epochensekunden

             #--- "kurzlebige" VZs/Dateien sind zwar ermittelt worden, bis 'stat' ausgefuehrt wurde
             #    existieren sie aber z.T. nicht mehr. Deshalb muss '$tMtime' noch auf Plausibilitaet
             #    geprueft werden.
             #
             #    2007-01-01 00:00:00  =  1167606000

             if (defined($tMtime)  &&  $tMtime>1167606000  &&  $tMtime<$tJetzt) {   # M-Time ist plausibel

                if ($tJetzt-$tMtime > $RmvFileAgeSeconds[$i]) {   # akt. VZ ist lt. Alter ein Loeschkandidat

                   print "Loesche Verzeichnis '$AktStartDir'\n" if $bPrototyping;

                   if (rmdir($AktStartDir) == 1) { # rmdir retourniert die Anzahl erfolgreich geloeschter Verzeichnisse
                      $sumAnzDirs++;
                   }
                   else {
                      print "Fehler beim Verzeichnis-Loeschen: '$!'\n" if $bDebug;
                   }
                }
             }
          }
       }

       $sumAnzDirsTotal += $sumAnzDirs;         # Gesamtsumme aktualisieren

     # $xxx = "Anzahl geloeschter Verzeichnisse.: " . InterPunkt($sumAnzDirs) . "\n"; Print2Log($xxx);
       $xxx = "Number of deleted directories......: " . InterPunkt($sumAnzDirs) . "\n"; Print2Log($xxx);

    }

    $xxx = "------------------------------------\n\n"; Print2Log($xxx);
 }

 #--- Abschluss-Infos (Zeit, Summen) ausgeben

#$xxx = "*** Insgesamt geloeschte Verzeichnisse/Dateien/Byte: " .
#       InterPunkt($sumAnzDirsTotal) . "/" . InterPunkt($sumAnzFilesTotal) . "/" . InterPunkt($sumAnzBytesTotal) . "\n" .
#       "*** Ende des Loeschlaufs per " . GetActDateTime('Dt') . "\n" .
#       "-" x 100 . "\n\n";

 $xxx = "*** Total amount of deleted directories/files/bytes: " .
        InterPunkt($sumAnzDirsTotal) . "/" . InterPunkt($sumAnzFilesTotal) . "/" . InterPunkt($sumAnzBytesTotal) . "\n" .
        "*** End of file deletion at " . GetActDateTime('Dt') . "\n" .
        "-" x 100 . "\n\n";

 Print2Log($xxx);

 close(LOG);

 exit 0;


#-----------------------------------------------------------------------------------
#---   Subroutinen und Funktionen   ------------------------------------------------
#-----------------------------------------------------------------------------------

 #-----------------------------------------------------------------------------------
 # Name: GetVars()
 #
 # Zweck: Zuweisungen zu Variablen aus externer Datei (1. Parameter) zeilenweise lesen
 #        und mittels 'eval' ausfuehren. Im Gegensatz zu 'do' wird 'eval' im Scope des
 #        Aufrufers ausgefuehrt.
 #
 # Parameter: 1. DSN der Konfigurationsdatei, deren Zeilen ausgefuehrt werden
 #
 # Interne Routinen: keine
 #
 # Globale Groeszen: alle Zuweisungen, die sich durch Ausfuehrung ('eval') der
 #                   Konfigurationsdatei ergeben
 #
 # Ergebnis: Globale Groeszen aus der Konfigurationsdatei sind eingestellt
 #-----------------------------------------------------------------------------------

sub GetVars {

 my $cfgDSN = $_[0];                     # Name der zu exekutierenden Konfigurationsdatei

# open(INFILE, "<", $cfgDSN) or die "Abbruch! Kann Konfigurationsdatei >$cfgDSN< nicht lesen. System meldet: $!.\n";
  open(INFILE, "<", $cfgDSN) or die "Abortion! Configuration file >$cfgDSN< cannot be read. System reports: $!.\n";

  while (my $zeile = <INFILE>){         # alle Zeilen ex Datei lesen
     chomp $zeile;                      # '\n' am Zeilenende entfernen
     eval $zeile;
  }

  close(INFILE);

  return 1;
}

#------------------------------------------------------------------------------------

 #-----------------------------------------------------------------------------------
 # Name: NewLogfileRequired ()
 #
 # Zweck: Pruefen, ob das aktuelle Logfile die Maximalgroesze ueberschritten hat.
 #        Ist dies der Fall, wird es gesichert. Zuvor werden die aelteren Sicherungen
 #        um eine Generation nach hinten verschoben, wobei die Maximalanzahl an
 #        Sicherungen limitiert ist.
 #        Nach der Sicherung wird das Logfile auf die Laenge Null gekuerzt.
 #
 # Parameter: keine
 #
 # Interne Routinen: keine
 #
 # Globale Groeszen: gblLogfileDsn   ... Name des Logfiles
 #                   gblLogfileSize  ... Max. Groesze des Logfiles
 #                   gblLogfileCount ... Anzahl Sicherungen des Logfiles
 #
 # Ergebnis: 1 ... Logfiles wurden gesichert und aktuelles auf Laenge null gekuerzt
 #           0 ... Logfile nicht vorhanden oder noch nicht so grosz, dass es gesichert werden muss
 #-----------------------------------------------------------------------------------

sub NewLogfileRequired {

 use File::Copy;

 my ($fcnt, $quelle, $ziel, @stats);
 my $fsize = -s $gblLogfileDsn;

  if (!defined($fsize) || $fsize <= $gblLogfileSize) {
     return 0;
  }


  #--- Alte Sicherungen verschieben
  for ($fcnt = $gblLogfileCount-1; $fcnt>=1; $fcnt--) {

     $quelle = $gblLogfileDsn . "." . $fcnt;
     $ziel   = $gblLogfileDsn . "." . ($fcnt+1);

#    print "fcnt ist..: >$fcnt<\n";
#    print "Quelle ist: >$quelle<\n";
#    print "Ziel   ist: >$ziel<\n";

     if (-e $quelle) {
#       print "Copy wird ausgefuehrt!\n";
        copy($quelle, $ziel);

        if ($^O ne "MSWin32") {  # unter Unix die Timestamp am Ziel korrigieren
           @stats = (stat($quelle)) [8,9];
           utime @stats, $ziel;
        }
     }

  }

  #--- Aktuelle Datei sichern
  $quelle = $gblLogfileDsn;
  $ziel   = $gblLogfileDsn . ".1";
  copy($quelle, $ziel);
  if ($^O ne "MSWin32") {  # unter Unix die Timestamp am Ziel korrigieren
     @stats = (stat($quelle)) [8,9];
     utime @stats, $ziel;
  }

  #--- Aktuelle Datei zuruecksetzen
# open my $fh, ">", $quelle or warn "Kann Datei '$quelle' nicht zuruecksetzen. System meldet: $!\n";
  open my $fh, ">", $quelle or warn "File '$quelle' cannot be resetted. System reports: $!\n";
  close($fh);

  return 1;
}

#------------------------------------------------------------------------------------

 #-----------------------------------------------------------------------------------
 # Name: Print2Log()
 #
 # Zweck: Voll aufbereitete Zeichenkette auf den globalen Filehandle LOG ausgeben.
 #        Im Debug-Modus ($bDebug ist wahr) oder unter Win32 wird die Zeichenkette
 #        zusaetzlich auf StdOut ausgegeben.
 #
 # Parameter: 1. auzugebende Zeichenkette
 #
 # Interne Routinen: keine
 #
 # Globale Groeszen: LOG     ... Filehandle fuer Logdatei
 #                   $bDebug ... Debug-Output gewuenscht J/N
 #
 # Ergebnis: 1 (immer)
 #-----------------------------------------------------------------------------------

sub Print2Log {

 my $zeile = $_[0];                      # auszugebende Textzeile, voll aufbereitet

  print LOG $zeile;

  if ($^O eq "MSWin32"  || $bDebug) { print $zeile; }

  return 1;
}

#------------------------------------------------------------------------------------

 #-----------------------------------------------------------------------------------
 # Name: InterPunkt()
 #
 # Zweck: Eine uebergebene Zahl (1. Parameter) mit Tausenderpunkten versehen.
 #        Zudem kann die Breite der Aufbereitung fuer die Stellen vor und nach dem
 #        Dezimalzeichen vorgegeben werden. Werden aber zu wenig Vorkommastellen
 #        vorgegeben, wird diese Vorgabe ignoriert. In der Breite fuer die
 #        Vorkommastellen muessen die '.' fuer die Gruppierung und das ev.
 #        vorhandene Minusvorzeichen mitgezaehlt werden.
 #        Ggf. wird das Ergebnis links mit fuehrenden Leerstellen aufgefuellt.
 #
 #        Das Ergebnis wird im Dezimalteil gerundet, wenn die urspruengliche Zahl mehr
 #        Dezimalstellen aufweist, als durch die Aufbereitung gewuenscht werden.
 #
 #        Wird die gewuenschte Breite des Vorkommateils nicht (oder als '') spezifiziert,
 #        werden nur Tausenderunkte eingefuegt. Gleiches gilt fuer die Nachkommastellen.
 #        Werden sie nicht spezifiziert, werden sie unveraendert uebernommen.
 #
 #        Die Zahl muss Perl-konform mit '.' als Dezimalzeichen uebergeben werden, bei
 #        der Aufbereitung erfolgt dann die Tausendergruppierung  mit '.', das
 #        Dezimalzeichen ist ','. Die Zahl darf auch negativ sein.
 #
 # Beispiele:
 #
 #   Zahl        VK  NK          Ergebnis
 #  -----------------------------------------
 #   12                             "12"
 #  -12                            "-12"
 #   123                           "123"
 #  -123                          "-123"
 #   1234                        "1.234"
 #  -1234                       "-1.234"
 #   1234567                 "1.234.567"
 #  -1234567                "-1.234.567"
 #   1234.45                     "1.234,45"
 #   1234.450                    "1.234,450"
 #  -1234.450                   "-1.234,450"
 #  -1234.45                    "-1.234,45"
 #
 #  -1234567     12  3    "  -1.234.567,000"
 #  -1234567.12  12  3    "  -1.234.567,120"
 #  -1234567.12   5  3      "-1.234.567,120"    VK=5 ignoriert, da zu klein!
 #  +1234567.12   5  3       "1.234.567,120"    VK=5 ignoriert, da zu klein!
 #  +1234567.12  12  3    "   1.234.567,120"
 #  -1234.45      5  5          "-1.234,45000"  VK=5 ignoriert, da zu klein!
 #   12345.67     0  3          "12.345,670"
 #  -12345.67     0  3         "-12.345,670"
 #  -12345.67     0  4         "-12.345,6700"
 #  -12345.67     5  4         "-12.345,6700"   VK=5 ignoriert, da zu klein!
 #  -12345.67    12  4    "     -12.345,6700"
 #   12345.67     0  1          "12.345,7"      Rundung auf 1 Dezimale
 #  -12345.67     0  1         "-12.345,7"      Rundung auf 1 Dezimale
 #
 #  -12345.67     0  0         "-12.346"        VK=0 ignoriert, da zu klein! Rundung auf Einer
 #  -12345.67     2  0         "-12.346"        VK=2 ignoriert, da zu klein! Rundung auf Einer
 #  -12345.67    12  0    "     -12.346"        Rundung (auf Einer = 0 Dezimalen)
 #
 #  -12345.67     8           " -12.345,67"
 #  -12345.67        4         "-12.345,6700"
 #
 # Parameter: 1. [muss] aufzubereitende Zahl.  "." gilt als Dezimalzeichen.
 #            2. [kann] Laenge der Vorkommastellen
 #            3. [kann] Laenge der Nachkommastellen
 #
 # Interne Routinen: keine
 #
 # Benoetigte Module: keine
 #
 # Globale Groeszen: keine
 #
 # Ergebnis: Zahl gemaesz lokalen Regeln mit Tausender-Punkten aufbereitet
 #-----------------------------------------------------------------------------------

sub InterPunkt {

 my ($erg, $vk, $nk) = @_;
 my ($vkS, $vkSl);

 if (!defined($vk) || $vk eq '') {$vk = -1};
 if (!defined($nk) || $nk eq '') {$nk = -1};

  # print "erg: >$erg<  vk: >$vk<   nk: >$nk<.";

  if ($nk >= 0) {                       # explizite Anzahl an Nachkommastellen gewuenscht
     $erg = sprintf "%.${nk}f", $erg;   # gemaesz Anzahl gewuenschter Nachkommastellen aufbereiten
  }

  # Bei jedem Schleifendurchlauf ein Komma nach 3 Ziffern (von rechts) hinzufuegen
  1 while $erg =~ s/^(-?\d+)(\d\d\d)/$1,$2/;

  $erg =~ tr/.,/,./;                    # gemaesz lokalen Konventionen Tausenderpunkte und Dezimalzeichen

  if ($vk > 0) {                        # ggf. Vorkommateil linksbuendig mit Blanks auffuellen

     # Vorkommateil extrahieren. Alles falls kein Dezimalzeichen mehr vorhanden
     ($vkS) = $erg =~ /(.*),/; if (!defined($vkS)) {$vkS = $erg};

     $vkSl = length($vkS);
#    print "vkS: >$vkS<, lng: $vkSl\n";

     $vkSl = $vk - $vkSl;

     if ($vkSl > 0) {$erg = ' ' x $vkSl . $erg};
  }

  return $erg;

}

 #----------------------------------------------------------------------------------#

 #-----------------------------------------------------------------------------------
 # Name: GetActDateTime()
 #
 # Zweck: Aktuelles Datum und/oder Zeit ermitteln. Je nach Parameter '$sTyp' erfolgt die
 #        Aufbereitung. Jede einzelne Stelle von '$sTyp' beschreibt eine Aufbereitung,
 #        es werden alle aufbereiteten Teilergebnisse (mit Blank getrennt)
 #        aneinander gereiht retourniert.
 #
 # Parameter: 1. '$sTyp' ... gewuenschte Aufbereitung 'D' -> JJJJ-MM-TT
 #                                                    'd' -> TT.MM.JJJJ
 #                                                    't' -> HH:MM:SS
 #                           beliebige Kombinationen der Werte 'D', 'd' und 't' sind erlaubt
 #
 # Interne Routinen: keine
 #
 # Beispiele: GetActDateTime('Dt')     ===> '2006-05-11 10:49:15'
 #            GetActDateTime('Dtd')    ===> '2006-05-11 10:49:15 11.05.2006'
 #            GetActDateTime('t')      ===> '10:49:15'
 #            GetActDateTime('d')      ===> '11.05.2006'
 #
 # Globale Groeszen: keine
 #
 # Ergebnis: aufbereitetes aktuelles Datum und/oder Zeit.
 #-----------------------------------------------------------------------------------

sub GetActDateTime {

 my $sTyp = $_[0];                     # gewuenschte Aufbereitungen
 my ($sErg, $ix, $sTmp, $c);
 my ($tSS, $tMM, $tHH, $tTag, $tMon, $tJhr) = (localtime)[0..5]; $tMon += 1; $tJhr += 1900;

 $sTyp = 'dt' if ! defined($sTyp);

  foreach $ix (0..length($sTyp)-1) {
     $c = substr($sTyp, $ix, 1);

     if ($c =~ /D/) {
        $sTmp = sprintf "%04d-%02d-%02d", $tJhr, $tMon, $tTag;    # JJJJ-MM-TT
     } elsif ($c =~ /d/) {
        $sTmp = sprintf "%02d.%02d.%04d", $tTag, $tMon, $tJhr;    # TT.MM.JJJJ
     } else {
        $sTmp = sprintf "%02d:%02d:%02d", $tHH,  $tMM,  $tSS;     # HH:MM:SS
     }

     $sErg .= $ix>0 ? " $sTmp" : $sTmp;
  }

  return $sErg;

}

 #----------------------------------------------------------------------------------#

