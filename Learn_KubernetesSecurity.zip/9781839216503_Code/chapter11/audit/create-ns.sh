#!/bin/bash

kubectl create ns ns1
kubectl create ns ns2
kubectl create ns ns3
