#!/bin/bash

docker build -t kaizheh/anchore-cli .

docker push kaizheh/anchore-cli
