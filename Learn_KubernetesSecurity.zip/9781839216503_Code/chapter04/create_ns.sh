#!/bin/bash

kubectl create namespace test
