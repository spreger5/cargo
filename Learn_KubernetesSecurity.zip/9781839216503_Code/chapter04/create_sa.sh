#!/bin/bash

kubectl create serviceaccount demo-sa
