#!/bin/bash

kubectl create -f role.yaml
